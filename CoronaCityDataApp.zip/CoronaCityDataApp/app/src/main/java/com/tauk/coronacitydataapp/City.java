package com.tauk.coronacitydataapp;

public class City {
    public String cityName;
    public int numberOfCases;
    public int recoveries;

    public City() {

    }

    public City(String cityName, int numberOfCases, int recoveries) {
        this.cityName = cityName;
        this.numberOfCases = numberOfCases;
        this.recoveries = recoveries;
    }

    public String toString() {
        return cityName + " Cases:" + numberOfCases + " Recoveries: " + recoveries;
    }
}
