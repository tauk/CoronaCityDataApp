package com.tauk.coronacitydataapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class AddRemoveCoronaDataActivity extends AppCompatActivity {

    //declare variables as needed for edit texts, tvStatus .....
    private EditText etCity;
    private EditText etCases;
    private EditText etRecoveries;

    private TextView tvStatus;

    //declare variables for DatabaseReference ...............
    private DatabaseReference databaseReference;
    private DatabaseReference newCityReference;

    //declare variables for FirebaseAuth ............ (need this for logout)
    private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_remove_corona_data);

        //initialize FjrebaseApp....
        FirebaseApp.initializeApp(this);

        //initialize FirebaseAuth.....
        firebaseAuth = FirebaseAuth.getInstance();

        //initialize ****ALL**** the EditTexts ..........
        etCity = findViewById(R.id.etCity);
        etCases = findViewById(R.id.etCases);
        etRecoveries = findViewById(R.id.etRecoveries);

        //initialize TextView - tvStatus ..........
        tvStatus = findViewById(R.id.tvStatus);
    }

    //Add the code to add a new city and its related data ........
    public void doAddCityData(View view) {
        //write the code to add a new city and its related data ........
        //add the data under child node "cities" with key as the city.......
        //note the cases and recoveries are integers

        //get all the data from the edit texts............
        final String cityName = etCity.getText().toString();
        int cases = Integer.parseInt(etCases.getText().toString());
        int recoveries = Integer.parseInt(etRecoveries.getText().toString());

        //make a object using the model class that you have written
        City city = new City(cityName, cases, recoveries);

        //Add the node with the city name
        //then add the data under that new node.
        //get a reference to the Firebase database
        databaseReference = FirebaseDatabase.getInstance().getReference();

        if(databaseReference != null)
            Toast.makeText(this, databaseReference.toString(), Toast.LENGTH_LONG).show();

        //create a new node under which you will add the new car data
        Task task = databaseReference.child("cities").child(cityName).setValue("");

        task.addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()) {
                    tvStatus.setText(cityName + "added!");
                } else {
                    // If sign in fails, display a message to the user.
                    Log.w("doRegister", "createUserWithEmail:failure", task.getException());
                    tvStatus.setText("Add failed!!!" +task.getException());
                }

                // ...
            }
        });

        //get the reference to the city under /cities node
        newCityReference = databaseReference.child("/cities").child(cityName);

        //add the new city data
        newCityReference.setValue(city) //adds the data under cityName child node
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        // Write was successful!
                        Toast.makeText(AddRemoveCoronaDataActivity.this, cityName + " as added!!", Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        // Write failed
                        Toast.makeText(AddRemoveCoronaDataActivity.this, cityName + " db error!", Toast.LENGTH_SHORT).show();
                    }
                });


    }

    //Delete a city by its name ..........
    public void doDeleteCityData(View view) {
        //write the code to delete a city by its name ..........
        final String cityName = etCity.getText().toString();

        //get a reference to the Firebase database
        databaseReference = FirebaseDatabase.getInstance().getReference();
        DatabaseReference carRef = databaseReference.child("/cities").child(cityName);

        if (carRef != null) {
            //a city exists with this name - delete
            Task removeTask = carRef.removeValue();
            removeTask.addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()) {
                        tvStatus.setText(cityName + " removed!");
                    } else {
                        // If sign in fails, display a message to the user.
                        Log.w("doRegister", "remove car:failure", task.getException());
                        tvStatus.setText("remove failed!!!" +task.getException());
                    }
                    // ...
                }
            });
        }
        else {
            Toast.makeText(AddRemoveCoronaDataActivity.this, cityName + " not found!", Toast.LENGTH_LONG).show();
        }
    }

    //write the code to move to the ViewAllCitiesDataActivity ..........
    public void doViewAllCitiesData(View view) {
        //write the code to move to the ViewAllCitiesDataActivity ..........
        Intent intent = new Intent(this, ViewAllCitiesDataActivity.class);
        startActivity(intent);
    }


    //Write the code to logout the current user and close the current activity
    public void doLogout(View view) {
        //Write the code to logout the current user and close the current activity
        firebaseAuth.signOut();
        finish();
    }

}
